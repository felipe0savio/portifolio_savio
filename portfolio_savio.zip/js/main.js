// JS opcional (não é exigência do enunciado).
// - Controla a abertura/fechamento do menu em telas pequenas.
// - Atualiza o ano no rodapé automaticamente.
// - Faz contagem de caracteres no textarea do formulário de contato.

(function () {
  const navToggle = document.getElementById('navToggle');
  const siteNav = document.getElementById('siteNav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const open = siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(open));
    });
  }

  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const textarea = document.getElementById('mensagem');
  const contador = document.getElementById('contador');
  if (textarea && contador) {
    const update = () => {
      contador.textContent = `${textarea.value.length}/500`;
    };
    textarea.addEventListener('input', update);
    update();
  }
})();
